package cryodex.xml;

public interface XMLObject {
	public StringBuilder appendXML(StringBuilder sb);
}
