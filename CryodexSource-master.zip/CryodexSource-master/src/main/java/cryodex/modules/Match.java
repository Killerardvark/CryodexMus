package cryodex.modules;

import cryodex.CryodexController;
import cryodex.Player;
import cryodex.xml.XMLObject;
import cryodex.xml.XMLUtils;
import cryodex.xml.XMLUtils.Element;

public class Match implements XMLObject {


    private Player player1;
    private Player player2;
    private Player player3;
    private Player player4;
    private Integer player1Points;
    private Integer player2Points;
    private Integer player3Points;
    private Integer player4Points;
    private String matchLabel;
    
    public Match() {

    }

    public Match(Player player1, Player player2, Player player3, Player player4) {
        this.player1 = player1;
        this.player2 = player2;
        this.player3 = player3;
        this.player4 = player4;
    }

    public Match(Element matchElement) {

        String player1String = matchElement.getStringFromChild("PLAYER1");
        player1 = CryodexController.getPlayerByID(player1String);

        String player2String = matchElement.getStringFromChild("PLAYER2");
        player2 = CryodexController.getPlayerByID(player2String);
        

        String player3String = matchElement.getStringFromChild("PLAYER3");
        player3 = CryodexController.getPlayerByID(player3String);
        

        String player4String = matchElement.getStringFromChild("PLAYER4");
        player4 = CryodexController.getPlayerByID(player4String);

       
        player1Points = matchElement.getIntegerFromChild("PLAYER1POINTS");
        player2Points = matchElement.getIntegerFromChild("PLAYER2POINTS");
        player3Points = matchElement.getIntegerFromChild("PLAYER3POINTS");
        player4Points = matchElement.getIntegerFromChild("PLAYER4POINTS");

        matchLabel = matchElement.getStringFromChild("MATCHLABEL");
    }

   

    public void clear() {

        player1 = null;
        player2 = null;
        player3 = null;
        player4 = null;
        matchLabel = null;
    }


    public Player getPlayer1() {
		return player1;
	}

	public void setPlayer1(Player player1) {
		this.player1 = player1;
	}

	public Player getPlayer2() {
		return player2;
	}

	public void setPlayer2(Player player2) {
		this.player2 = player2;
	}

	public Player getPlayer3() {
		return player3;
	}

	public void setPlayer3(Player player3) {
		this.player3 = player3;
	}

	public Player getPlayer4() {
		return player4;
	}

	public void setPlayer4(Player player4) {
		this.player4 = player4;
	}

	public Integer getPlayer1Points() {
		return player1Points;
	}

	public void setPlayer1Points(Integer player1Points) {
		this.player1Points = player1Points;
	}

	public Integer getPlayer2Points() {
		return player2Points;
	}

	public void setPlayer2Points(Integer player2Points) {
		this.player2Points = player2Points;
	}

	public Integer getPlayer3Points() {
		return player3Points;
	}

	public void setPlayer3Points(Integer player3Points) {
		this.player3Points = player3Points;
	}

	public Integer getPlayer4Points() {
		return player4Points;
	}

	public void setPlayer4Points(Integer player4Points) {
		this.player4Points = player4Points;
	}

	public String getMatchLabel() {
		return matchLabel;
	}

	public void setMatchLabel(String matchLabel) {
		this.matchLabel = matchLabel;
	}

	@Override
    public String toString() {
        return getPlayer1() + " vs " + getPlayer2();
    }
	
	public boolean isComplete(){
		if(getPlayer1Points() == null){
			return false;
		}
		if(getPlayer2Points() == null){
			return false;
		}
		if(getPlayer3Points() == null){
			return false;
		}
		if(getPlayer4Points() == null && getPlayer4() != null){
			return false;
		}
		return true;
	}

    @Override
    public StringBuilder appendXML(StringBuilder sb) {

        XMLUtils.appendObject(sb, "PLAYER1", getPlayer1().getSaveId());
        XMLUtils.appendObject(sb, "PLAYER2", getPlayer2().getSaveId());
        XMLUtils.appendObject(sb, "PLAYER3", getPlayer3().getSaveId());
        XMLUtils.appendObject(sb, "PLAYER4", getPlayer4() == null ? "" : getPlayer4().getSaveId());
        
        XMLUtils.appendObject(sb, "PLAYER1POINTS", getPlayer1Points());
        XMLUtils.appendObject(sb, "PLAYER2POINTS", getPlayer2Points());
        XMLUtils.appendObject(sb, "PLAYER3POINTS", getPlayer3Points());
        XMLUtils.appendObject(sb, "PLAYER4POINTS", getPlayer4Points());
        XMLUtils.appendObject(sb, "MATCHLABEL", matchLabel);

        return sb;
    }
}
