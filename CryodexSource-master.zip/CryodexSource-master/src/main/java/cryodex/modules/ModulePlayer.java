package cryodex.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cryodex.Player;
import cryodex.xml.XMLObject;
import cryodex.xml.XMLUtils;
import cryodex.xml.XMLUtils.Element;

/**
 * Contains the generic functions that exist in all standard game types. Also contains a value cache to decrease
 * expensive and redundant calculations.
 */
public abstract class ModulePlayer implements Comparable<ModulePlayer>, XMLObject {

    private Map<String, Integer> integerStatistics = new HashMap<String, Integer>();
    private Map<String, Double> doubleStatistics = new HashMap<String, Double>();

    private Player player;
    private String seedValue;

    /**
     * Standard constructor for a new player. Creates a new random seed value.
     * 
     * @param player
     */
    public ModulePlayer(Player player) {
        this.player = player;
        seedValue = String.valueOf(Math.random());
    }

    /**
     * Constructor for loading a player from an XML save.
     * 
     * @param player
     * @param e
     */
    public ModulePlayer(Player player, Element e) {
        this.player = player;

        this.seedValue = e.getStringFromChild("SEEDVALUE");
    }

    /**
     * Get random seed value for player for this game type.
     * 
     * @return randomly generated seed number as a string
     */
    public String getSeedValue() {
        return seedValue;
    }

    /**
     * Return the cached integer value for the statName in the given tournament.
     * 
     * @param tournament
     *            - which event to pull the value from
     * @param statName
     *            - which value to pull
     * @return integer value if it has been cached. Otherwise null.
     */
    protected Integer getPlayerStatisticInteger(Tournament tournament, String statName) {

        Integer value = integerStatistics.get(tournament.getName() + statName);

        return value;
    }

    /**
     * Save an integer value of the statName for the given tournament which can be retrieved later using the
     * getPlayerStatisticInteger function
     * 
     * @param tournament
     *            - which even this value is being saved for
     * @param statName
     *            - which value is being saved
     * @param value
     *            - integer value to be saved
     */
    protected void putPlayerStatisticInteger(Tournament tournament, String statName, Integer value) {
        integerStatistics.put(tournament.getName() + statName, value);
    }

    /**
     * Return the cached double value for the statName in the given tournament.
     * 
     * @param tournament
     *            - which event to pull the value from
     * @param statName
     *            - which value to pull
     * @return double value if it has been cached. Otherwise null.
     */
    protected Double getPlayerStatisticDouble(Tournament tournament, String statName) {
        Double value = doubleStatistics.get(tournament.getName() + statName);

        return value;
    }

    /**
     * Save an double value of the statName for the given tournament which can be retrieved later using the
     * getPlayerStatisticDouble function
     * 
     * @param tournament
     *            - which even this value is being saved for
     * @param statName
     *            - which value is being saved
     * @param value
     *            - double value to be saved
     */
    protected void putPlayerStatisticDouble(Tournament tournament, String statName, Double value) {
        doubleStatistics.put(tournament.getName() + statName, value);
    }

    /**
     * Removes all values from the cache to force recalculation.
     */
    public void clearCache() {
        integerStatistics.clear();
        doubleStatistics.clear();
    }

    /**
     * @return the generic Player object associated with this ModulePlayer
     */
    public Player getPlayer() {
        return player;
    }

    /**
     * @return the player name
     */
    public String getName() {
        return getPlayer().getName();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(ModulePlayer arg0) {
        return this.getPlayer().getName().toUpperCase().compareTo(arg0.getPlayer().getName().toUpperCase());
    }

    /**
     * Calculates the round a player dropped from the given tournament. The value returned is the first round the player
     * does not exist in. For example, if the player had a match in rounds 1, 2, and 3, the function would return a 4.
     * 
     * @param t
     *            - tournament to calculate from
     * @return the first round a player did not play as an integer
     */
    public int getRoundDropped(Tournament t) {

        Integer roundDropped = getPlayerStatisticInteger(t, "RoundDropped");

        if (roundDropped != null) {
            return roundDropped;
        }

        roundDropped = 0;

        for (int i = t.getAllRounds().size(); i > 0; i--) {

            boolean found = false;
            Round r = t.getAllRounds().get(i - 1);
            for (Match m : r.getMatches()) {
                found = isPlayer(m);
                if (found){
                	break;
                }
            }

            if (found) {
                roundDropped = i + 1;
                break;
            }
        }

        putPlayerStatisticInteger(t, "RoundDropped", roundDropped);

        return roundDropped;
    }
    
    public boolean isPlayer(Match m) {
    	if (m.getPlayer1() == this.getPlayer()) {
            return true;
        } else if (m.getPlayer2() == this.getPlayer()) {
        	return true;
        } else if (m.getPlayer3() == this.getPlayer()) {
        	return true;
        } else if (m.getPlayer4() == this.getPlayer()) {
        	return true;
        }
    	return false;
    }

    /**
     * Returns the player rank based on the event's ranking comparator
     * 
     * @param t
     *            - the tournament to calculate from
     * @return the player rank as an integer
     */
    public int getRank(Tournament t) {

        Integer rank = getPlayerStatisticInteger(t, "Rank");

        if (rank != null) {
            return rank;
        }

        rank = 0;

        List<Player> players = new ArrayList<Player>();
        players.addAll(t.getPlayers());
        Collections.sort(players, t.getRankingComparator());

        for (int i = 0; i < players.size(); i++) {
            if (t.getModulePlayer(players.get(i)) == this) {
                rank = i + 1;
                break;
            }
        }

        putPlayerStatisticInteger(t, "Rank", rank);

        return rank;
    }

    

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return getPlayer().getName();
    }

    /*
     * (non-Javadoc)
     * 
     * @see cryodex.xml.XMLObject#appendXML(java.lang.StringBuilder)
     */
    @Override
    public StringBuilder appendXML(StringBuilder sb) {

        clearCache();

        XMLUtils.appendObject(sb, "SEEDVALUE", getSeedValue());
        XMLUtils.appendObject(sb, "MODULE", getModuleName());

        return sb;
    }

    /**
     * @return the module name for the event this player is from
     */
    public abstract String getModuleName();

    /**
     * This function calculates the score for a player in a given tournament type
     * 
     * @param t
     *            - tournament to calculate from
     * @return the score as an integer value
     */
    public abstract int getScore(Tournament t);
}
