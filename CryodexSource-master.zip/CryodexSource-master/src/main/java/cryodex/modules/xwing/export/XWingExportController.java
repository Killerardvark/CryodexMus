package cryodex.modules.xwing.export;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cryodex.Player;
import cryodex.export.ExportUtils;
import cryodex.modules.ExportController;
import cryodex.modules.Match;
import cryodex.modules.Tournament;
import cryodex.modules.xwing.XWingModule;
import cryodex.modules.xwing.XWingPlayer;
import cryodex.modules.xwing.XWingPlayer.Faction;
import cryodex.modules.xwing.XWingTournament;

public class XWingExportController extends ExportController {

    public String appendRankings(Tournament tournament) {
        List<Player> playerList = new ArrayList<Player>();
        playerList.addAll(tournament.getAllPlayers());
        
        return appendRanking(playerList, tournament);
    }
    
    public String appendRanking(List<Player> playerList, Tournament tournament){
        List<Player> activePlayers = tournament.getPlayers();

        Collections.sort(playerList, tournament.getRankingComparator());
    	
    	String content = "<table border=\"1\">";

        content = appendHTMLTableHeader(content, "Rank", "Name", "Faction", "Score", "VP", "SoS");

        for (Player p : playerList) {

            XWingPlayer xp = ((XWingTournament) tournament).getModulePlayer(p);

            String name = p.getName();
            String faction = xp.getFaction() == null ? "" : xp.getFaction().toString();

            if (activePlayers.contains(p) == false) {
                name = "(D#" + xp.getRoundDropped(tournament) + ")" + name;
            }

            content = appendHTMLTableRow(content, xp.getRank(tournament), name, faction, xp.getScore(tournament), xp.getVP(tournament),
                    xp.getSOS(tournament));
        }

        content += "</table>";
        
        return content;
    }

    @Override
    public String getValueLabel() {
        return "Points Destroyed";
    }

    @Override
    public String getMatchStats(Match match, Tournament tournament) {

//        String matchString = "<table class=\"print-friendly\" border=\"1\">";

//        XWingPlayer xp1 = (XWingPlayer) tournament.getModulePlayer(match.getPlayer1());
//        XWingPlayer xp2 = (XWingPlayer) tournament.getModulePlayer(match.getPlayer2());
//
//        matchString += appendHTMLTableHeader("Name", "Rank", "Score", "MoV", "SoS");
//
//        matchString += appendHTMLTableRow(xp1.getName(), xp1.getRank(tournament), xp1.getScore(tournament), xp1.getVP(tournament),
//                xp1.getAverageSoS(tournament));
//        matchString += appendHTMLTableRow(xp2.getName(), xp2.getRank(tournament), xp2.getScore(tournament), xp2.getVP(tournament),
//                xp2.getAverageSoS(tournament));
//
//        matchString += "</table>";
//
//        matchString = matchString.replaceAll("<td>", "<td class=\"smallFont\">");

        return "";
    }


    @Override
    public void tcxTeamReport(Tournament tournament) {
        // Do nothing
    }

	@Override
	public void exportMultiTournamentReport(List<Tournament> tournaments) {}

	@Override
	public void exportByFaction(Tournament tournament) {
		String content = "";
		
		Map<Faction, List<Player>> factionMap = new HashMap<Faction, List<Player>>();
		
		for(Player p : tournament.getAllPlayers()){
			XWingPlayer xwp = (XWingPlayer) p.getModuleInfoByModule(XWingModule.getInstance());
			
			List<Player> factionList = factionMap.get(xwp.getFaction());
			
			if(factionList == null){
				factionList = new ArrayList<Player>();
				factionMap.put(xwp.getFaction(), factionList);
			}
			
			factionList.add(p);
		}
		
		for(Faction f : factionMap.keySet()){
			
			content += "<h1>" + f.toString() + "</h1><br>";
			
			List<Player> players = factionMap.get(f);
			
			content += appendRanking(players, tournament);
		}
		
		ExportUtils.displayHTML(content, "ExportFactionRankings");
	}

	@Override
	public void cacReport() {
		// TODO Auto-generated method stub
		
	}
}
