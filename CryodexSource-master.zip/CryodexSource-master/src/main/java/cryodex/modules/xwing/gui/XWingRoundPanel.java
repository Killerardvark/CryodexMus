package cryodex.modules.xwing.gui;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JPanel;

import cryodex.CryodexController;
import cryodex.modules.Match;
import cryodex.modules.RoundPanel;
import cryodex.modules.Tournament;
import cryodex.widget.ComponentUtils;
import cryodex.widget.ConfirmationTextField;

public class XWingRoundPanel extends RoundPanel {

    private static final long serialVersionUID = 1L;

    public XWingRoundPanel(Tournament t, List<Match> matches) {
        super(t, matches);

    }

    public void buildGamePanel(JPanel panel, GridBagConstraints gbc, RoundPanel.GamePanel gamePanel) {

        GamePanel gp = (GamePanel) gamePanel;

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(gp.getPlayerTitle(), gbc);

            gbc.gridy++;
            gbc.gridwidth = 1;
            gbc.fill = GridBagConstraints.NONE;

            gbc.gridx = 1;
            panel.add(gp.getPlayer1KillLabel(), gbc);

            gbc.gridx = 2;
            panel.add(gp.getPlayer1KillPointsField(), gbc);

            gbc.gridx = 3;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(gp.getPlayer1KillPointsField().getIndicator(), gbc);

            gbc.gridy++;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.EAST;

            gbc.gridx = 1;
            panel.add(gp.getPlayer2KillLabel(), gbc);

            gbc.gridx = 2;
            panel.add(gp.getPlayer2KillPointsField(), gbc);

            gbc.gridx = 3;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(gp.getPlayer2KillPointsField().getIndicator(), gbc);

            gbc.gridy++;
            gbc.gridwidth = 1;
            gbc.anchor = GridBagConstraints.EAST;

            gbc.gridx = 1;
            panel.add(gp.getPlayer3KillLabel(), gbc);

            gbc.gridx = 2;
            panel.add(gp.getPlayer3KillPointsField(), gbc);

            gbc.gridx = 3;
            gbc.anchor = GridBagConstraints.WEST;
            panel.add(gp.getPlayer3KillPointsField().getIndicator(), gbc);
            
            if (gp.getMatch().getPlayer4() != null) {

                gbc.gridy++;
                gbc.gridwidth = 1;
                gbc.anchor = GridBagConstraints.EAST;

                gbc.gridx = 1;
                panel.add(gp.getPlayer4KillLabel(), gbc);

                gbc.gridx = 2;
                panel.add(gp.getPlayer4KillPointsField(), gbc);

                gbc.gridx = 3;
                gbc.anchor = GridBagConstraints.WEST;
                panel.add(gp.getPlayer4KillPointsField().getIndicator(), gbc);
            }
    }

    @Override
    public List<RoundPanel.GamePanel> getGamePanels(List<Match> matches) {
        List<RoundPanel.GamePanel> gamePanels = new ArrayList<RoundPanel.GamePanel>();

        int counter = 0;
        for (Match match : matches) {
            counter++;
            GamePanel gp = new GamePanel(counter, match);
            gamePanels.add(gp);
        }

        return gamePanels;
    }

    private class GamePanel extends RoundPanel.GamePanel {

        private ConfirmationTextField player1KillPoints;
        private ConfirmationTextField player2KillPoints;
        private ConfirmationTextField player3KillPoints;
        private ConfirmationTextField player4KillPoints;
        private JLabel player1KillLabel;
        private JLabel player2KillLabel;
        private JLabel player3KillLabel;
        private JLabel player4KillLabel;

        public GamePanel(int tableNumber, Match match) {
            super(tableNumber, match);
        }

        private JLabel getPlayer1KillLabel() {
            if (player1KillLabel == null) {
                player1KillLabel = new JLabel();
            }
            return player1KillLabel;
        }

        private JLabel getPlayer2KillLabel() {
            if (player2KillLabel == null) {
                player2KillLabel = new JLabel();
            }
            return player2KillLabel;
        }
        
        private JLabel getPlayer3KillLabel() {
            if (player3KillLabel == null) {
                player3KillLabel = new JLabel();
            }
            return player3KillLabel;
        }
        
        private JLabel getPlayer4KillLabel() {
            if (player4KillLabel == null) {
                player4KillLabel = new JLabel();
            }
            return player4KillLabel;
        }

        public ConfirmationTextField getPlayer1KillPointsField() {
            if (player1KillPoints == null) {
                player1KillPoints = new ConfirmationTextField();
                player1KillPoints.addFocusListener(GamePanel.this);
                ComponentUtils.forceSize(player1KillPoints, 50, 25);
            }

            return player1KillPoints;
        }

        public ConfirmationTextField getPlayer2KillPointsField() {
            if (player2KillPoints == null) {
                player2KillPoints = new ConfirmationTextField();
                player2KillPoints.addFocusListener(GamePanel.this);
                ComponentUtils.forceSize(player2KillPoints, 50, 25);
            }

            return player2KillPoints;
        }
        
        public ConfirmationTextField getPlayer3KillPointsField() {
            if (player3KillPoints == null) {
                player3KillPoints = new ConfirmationTextField();
                player3KillPoints.addFocusListener(GamePanel.this);
                ComponentUtils.forceSize(player3KillPoints, 50, 25);
            }

            return player3KillPoints;
        }
        
        public ConfirmationTextField getPlayer4KillPointsField() {
            if (player4KillPoints == null) {
                player4KillPoints = new ConfirmationTextField();
                player4KillPoints.addFocusListener(GamePanel.this);
                ComponentUtils.forceSize(player4KillPoints, 50, 25);
            }

            return player4KillPoints;
        }

        public void setMatchPointsFromGUI() {
            // Set player 1 points
            Integer player1points = null;
            try {
                player1points = Integer.valueOf(player1KillPoints.getText());
            } catch (Exception e) {

            }
            getMatch().setPlayer1Points(player1points);

            // Set player 2 points
            Integer player2points = null;
            try {
                player2points = Integer.valueOf(player2KillPoints.getText());
            } catch (Exception e) {

            }
            getMatch().setPlayer2Points(player2points);
            
         // Set player 3 points
            Integer player3points = null;
            try {
                player3points = Integer.valueOf(player3KillPoints.getText());
            } catch (Exception e) {

            }
            getMatch().setPlayer3Points(player3points);
            
         // Set player 4 points
            Integer player4points = null;
            try {
                player4points = Integer.valueOf(player4KillPoints.getText());
            } catch (Exception e) {

            }
            getMatch().setPlayer4Points(player4points);
        }

        public void setGUIFromMatch() {

            if (getMatch().getPlayer1Points() != null) {
                getPlayer1KillPointsField().setText(String.valueOf(getMatch().getPlayer1Points()));
            }
            if (getMatch().getPlayer2Points() != null) {
                getPlayer2KillPointsField().setText(String.valueOf(getMatch().getPlayer2Points()));
            }
            if (getMatch().getPlayer3Points() != null) {
                getPlayer3KillPointsField().setText(String.valueOf(getMatch().getPlayer3Points()));
            }
            if (getMatch().getPlayer4Points() != null) {
                getPlayer4KillPointsField().setText(String.valueOf(getMatch().getPlayer4Points()));
            }

            updateGUI();
        }

        public void updateGUI() {
            String titleText = null;

            boolean showKillPoints = true;
            boolean hideCompletedMatches = CryodexController.getOptions().isHideCompleted();

            boolean visible = hideCompletedMatches == false || getTournament().isMatchComplete(getMatch()) == false;

            getPlayer1KillLabel().setVisible(visible && showKillPoints);
            getPlayer1KillPointsField().setVisible(visible && showKillPoints);
            getPlayer2KillLabel().setVisible(visible && showKillPoints);
            getPlayer2KillPointsField().setVisible(visible && showKillPoints);
            getPlayer3KillLabel().setVisible(visible && showKillPoints);
            getPlayer3KillPointsField().setVisible(visible && showKillPoints);
            getPlayer4KillLabel().setVisible(visible && showKillPoints);
            getPlayer4KillPointsField().setVisible(visible && showKillPoints);
            getPlayerTitle().setVisible(visible);

                titleText = getMatch().getPlayer1().getName() + " VS " + getMatch().getPlayer2().getName();
            
                if (CryodexController.getOptions().isShowTableNumbers()) {
                    titleText = getTableNumber() + ": " + titleText;
                }

                getPlayer1KillLabel().setText(getMatch().getPlayer1().getName() + " victory points");
                getPlayer2KillLabel().setText(getMatch().getPlayer2().getName() + " victory points");
                getPlayer3KillLabel().setText(getMatch().getPlayer3().getName() + " victory points");
                if(getMatch().getPlayer4() != null){
                	getPlayer4KillLabel().setText(getMatch().getPlayer4().getName() + " victory points");
                }

            getPlayerTitle().setText(titleText);

            
        }

        @Override
        public void addToFocusPolicy(Vector<Component> order) {
            if (getMatch().getPlayer2() != null) {
                order.add(getPlayer1KillPointsField());
                order.add(getPlayer2KillPointsField());
                order.add(getPlayer3KillPointsField());
                order.add(getPlayer4KillPointsField());
            }
        }

		@Override
		public void setResultsCombo() {
			// Do nothing
		}

		@Override
		public void setMatchResultFromGUI() {
			// Do nothing
		}
    }

}
