package cryodex.modules.xwing.wizard;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import cryodex.widget.ComponentUtils;
import cryodex.widget.wizard.TournamentWizard;
import cryodex.widget.wizard.WizardUtils;
import cryodex.widget.wizard.pages.Page;

public class AdditionalOptionsPage implements Page {


    private JPanel pagePanel;

    @Override
    public JPanel getPanel() {

        TournamentWizard.getInstance().setButtonVisibility(true, null, true);

        TournamentWizard.getInstance().setMinimumSize(new Dimension(450, 500));


        if (pagePanel == null) {

            JPanel initialPairingPanel = new JPanel(new BorderLayout());

            JLabel header = new JLabel("<HTML><H3>There's nothing to add here. Hit finish.</H3></HTML>");

            initialPairingPanel.add(ComponentUtils.addToFlowLayout(header, FlowLayout.LEFT), BorderLayout.NORTH);

            pagePanel = new JPanel(new FlowLayout());

            pagePanel.add(initialPairingPanel);
        }

        return pagePanel;
    }

    @Override
    public void onNext() {
        // Do nothing
    }

    @Override
    public void onPrevious() {
        TournamentWizard.getInstance().goToPrevious();
    }

    @Override
    public void onFinish() {
        WizardUtils.createTournament();
    }
}