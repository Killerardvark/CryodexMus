package cryodex.modules.xwing;

import java.util.ArrayList;
import java.util.List;

import cryodex.CryodexController.Modules;
import cryodex.Player;
import cryodex.modules.Match;
import cryodex.modules.ModulePlayer;
import cryodex.modules.Round;
import cryodex.modules.Tournament;
import cryodex.xml.XMLUtils;
import cryodex.xml.XMLUtils.Element;

public class XWingPlayer extends ModulePlayer {

    public static enum Faction {
    	IMPERIAL, REBEL, SCUM, RESISTANCE, FIRST_ORDER, SEPARATISTS, REPUBLIC;
    }

    private String squadId;
    private Faction faction;

    public XWingPlayer(Player p) {
        super(p);
    }

    public XWingPlayer(Player p, Element e) {
        super(p, e);
        this.squadId = e.getStringFromChild("SQUADID");
        String factionString = e.getStringFromChild("FACTION");

        if (factionString != null && factionString.isEmpty() == false) {
            faction = Faction.valueOf(factionString);
        } else {
            faction = Faction.IMPERIAL;
        }
    }

    public String getSquadId() {
        return squadId;
    }

    public void setSquadId(String squadId) {
        this.squadId = squadId;
    }

    public Faction getFaction() {
        return faction;
    }

    public void setFaction(Faction faction) {
        this.faction = faction;
    }
    
    public int getSOS(Tournament t){
    	Integer sos = getPlayerStatisticInteger(t, "sos");
    	
    	if (sos != null) {
    		return sos;
    	}
    	
    	int totalSOS = 0;
        for (int i = t.getAllRounds().size(); i > 0; i--) {

            Round r = t.getAllRounds().get(i - 1);
            for (Match m : r.getMatches()) {
                if(isPlayer(m)){
                	totalSOS += getOthersMatchVictoryPoints(m);
                }
            }
        }
        sos = totalSOS;
    	
    	putPlayerStatisticInteger(t, "sos", sos);
    	
    	return sos;
    }

    public int getScore(Tournament t) {

        Integer score = getPlayerStatisticInteger(t, "Score");

        if (score != null) {
            return score;
        }

        int totalScore = 0;
        for (int i = t.getAllRounds().size(); i > 0; i--) {

            Round r = t.getAllRounds().get(i - 1);
            for (Match m : r.getMatches()) {
                if(isPlayer(m)){
                	totalScore += getMatchScore(m);
                }
            }
        }
        score = totalScore;

        putPlayerStatisticInteger(t, "Score", score);

        return score;
    }
    
    public int getVP(Tournament t) {

        Integer vp = getPlayerStatisticInteger(t, "VP");

        if (vp != null) {
            return vp;
        }

        int totalVP = 0;
        for (int i = t.getAllRounds().size(); i > 0; i--) {

            Round r = t.getAllRounds().get(i - 1);
            for (Match m : r.getMatches()) {
                if(isPlayer(m)){
                	totalVP += getMatchVictoryPoints(m);
                }
            }
        }
        vp = totalVP;

        putPlayerStatisticInteger(t, "VP", vp);

        return vp;
    }
    
    public boolean isPlayer(Match m) {
    	if (m.getPlayer1() == this.getPlayer()) {
            return true;
        } else if (m.getPlayer2() == this.getPlayer()) {
        	return true;
        } else if (m.getPlayer3() == this.getPlayer()) {
        	return true;
        } else if (m.getPlayer4() == this.getPlayer()) {
        	return true;
        }
    	return false;
    }
    
    public int getOthersMatchVictoryPoints(Match m) {
    	
    	int vp = 0;
    	
    	if(m.getPlayer1Points() != null) vp += m.getPlayer1Points();
        if(m.getPlayer2Points() != null) vp += m.getPlayer2Points();
        if(m.getPlayer3Points() != null) vp += m.getPlayer3Points();
        if(m.getPlayer4Points() != null) vp += m.getPlayer4Points();
    	
        if (m.getPlayer1() == this.getPlayer() && m.getPlayer1Points() != null) {
        	vp -= m.getPlayer1Points();
        } else if (m.getPlayer2() == this.getPlayer() && m.getPlayer2Points() != null) {
        	vp -= m.getPlayer2Points();
        } else if (m.getPlayer3() == this.getPlayer() && m.getPlayer3Points() != null) {
        	vp -= m.getPlayer3Points();
        } else if (m.getPlayer4() == this.getPlayer() && m.getPlayer4Points() != null) {
        	vp -= m.getPlayer4Points();
        }
    	
    	return vp;
    }
    
    public int getMatchVictoryPoints(Match m) {
    	
    	int vp = 0;
    	
    	if (m.getPlayer1() == this.getPlayer() && m.getPlayer1Points() != null) {
            vp += m.getPlayer1Points();
        } else if (m.getPlayer2() == this.getPlayer() && m.getPlayer2Points() != null) {
        	vp += m.getPlayer2Points();
        } else if (m.getPlayer3() == this.getPlayer() && m.getPlayer3Points() != null) {
        	vp += m.getPlayer3Points();
        } else if (m.getPlayer4() == this.getPlayer() && m.getPlayer4Points() != null) {
        	vp += m.getPlayer4Points();
        }
    	
    	return vp;
    }
    
    public int getMatchScore(Match m) {
    	int playerScore = getMatchVictoryPoints(m);
    	
    	if(m.isComplete() == false){
    		return 0;
    	}
    	
    	Integer player1Score = m.getPlayer1Points();
    	Integer player2Score = m.getPlayer2Points();
    	Integer player3Score = m.getPlayer3Points();
    	Integer player4Score = m.getPlayer4Points();
    	
    	int playersBehind = 0;
    	int playersEqual = 0;
    	if(player1Score != null){
    		if(playerScore < player1Score){
    			playersBehind++;
    		} else if(playerScore == player1Score){
    			playersEqual++;
    		}
    	}
    	if(player2Score != null){
    		if(playerScore < player2Score){
    			playersBehind++;
    		} else if(playerScore == player2Score){
    			playersEqual++;
    		}
    	}
    	if(player3Score != null){
    		if(playerScore < player3Score){
    			playersBehind++;
    		} else if(playerScore == player3Score){
    			playersEqual++;
    		}
    	}
    	if(player4Score != null){
    		if(playerScore < player4Score){
    			playersBehind++;
    		} else if(playerScore == player4Score){
    			playersEqual++;
    		}
    	}
    	
    	if(playersBehind == 0){
    		// First place
    		if(playersEqual == 2){
    			// 1/2 TIE
    			return 7;
    		} else if(playersEqual == 3){
    			// 1/2/3 TIE
    			return 6;
    		} else if(playersEqual == 4){
    			// 1/2/3/4 TIE
    			return 5;
    		} else {
    			return 8;
    		}
    	}
    	
    	if(playersBehind == 1){
    		// Second place
    		if(playersEqual == 2){
    			// 2/3 TIE
    			return 5;
    		} else if(playersEqual == 3){
    			// 2/3/4 TIE
    			return 4;
    		} else {
    			return 6;
    		}
    	}
    	
    	if(playersBehind == 2){
    		// Third place
    		if(playersEqual == 2) {
    			// 3/4 TIE
    			return 3;
    		} else {
    			return 4;
    		}
    	}
    	
    	if(playersBehind == 3){
    		return 2;
    	}
    	
    	return 0;
    }

    @Override
    public String getModuleName() {
        return Modules.XWING.getName();
    }

    @Override
    public StringBuilder appendXML(StringBuilder sb) {

        super.appendXML(sb);
        
        XMLUtils.appendObject(sb, "SQUADID", getSquadId());
        XMLUtils.appendObject(sb, "FACTION", getFaction());

        return sb;
    }

	public List<Integer> getShips() {
		String squadId = getSquadId();
		List<Integer> shipList = new ArrayList<Integer>();
		try{
			String[] splitSquad = squadId.split(",");
			for(String s : splitSquad){
				shipList.add(Integer.valueOf(s));
			}
		} catch (Exception e){
			return null;
		}
		return shipList;
	}

}
