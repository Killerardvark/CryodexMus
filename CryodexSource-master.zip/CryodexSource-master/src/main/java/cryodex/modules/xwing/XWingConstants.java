package cryodex.modules.xwing;

public class XWingConstants {
    public static int WIN_POINTS = 1;
    public static int BYE_POINTS = 1;
    public static int LOSS_POINTS = 0;
}
