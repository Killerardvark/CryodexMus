package cryodex.modules;

import javax.swing.JMenu;

public interface Menu {

	JMenu getMenu();

	void resetMenuBar();

}
