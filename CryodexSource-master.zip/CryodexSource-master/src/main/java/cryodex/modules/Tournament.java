package cryodex.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.Icon;
import javax.swing.JOptionPane;

import cryodex.CryodexController;
import cryodex.CryodexController.Modules;
import cryodex.Main;
import cryodex.Player;
import cryodex.widget.wizard.WizardOptions;
import cryodex.xml.XMLObject;
import cryodex.xml.XMLUtils;
import cryodex.xml.XMLUtils.Element;

public abstract class Tournament implements XMLObject {

    public enum InitialSeedingEnum {
        RANDOM, BY_GROUP, IN_ORDER;
    }

    private final List<Round> rounds;
    private List<Player> players;
    private InitialSeedingEnum seedingEnum;
    private TournamentGUI tournamentGUI;
    private String name;
    private List<Integer> points;
    private List<String> dependentTournaments;
    private Module module;
    private boolean isRandomPairing = true;

    public Tournament() {
        this(null);
    }

    public Tournament(WizardOptions wizardOptions) {

        // Initialize
        this.players = new ArrayList<>();
        this.rounds = new ArrayList<>();
        this.dependentTournaments = new ArrayList<>();
        this.seedingEnum = InitialSeedingEnum.RANDOM;

        // Default Values
        this.name = "";
        this.seedingEnum = null;
        this.points = null;
        this.isRandomPairing = true;

        if (wizardOptions != null) {
            // Load values
            this.name = wizardOptions.getName();
            this.seedingEnum = wizardOptions.getInitialSeedingEnum();
            this.points = wizardOptions.getPoints();
            this.isRandomPairing = wizardOptions.isRandomPairing();

            if (wizardOptions.getPlayerList() != null) {
                this.players.addAll(wizardOptions.getPlayerList());
            }
        }

        module = Modules.getModuleByName(getModuleName());
    }

    public void loadXML(Element tournamentElement) {

        String playerIDs = tournamentElement.getStringFromChild("PLAYERS");

        for (String s : playerIDs.split(",")) {
            Player p = CryodexController.getPlayerByID(s);
            if (p != null) {
                getPlayers().add(p);
            }
        }

        if (rounds == null || rounds.isEmpty()) {
            Element roundElement = tournamentElement.getChild("ROUNDS");
            for (Element e : roundElement.getChildren()) {
                rounds.add(new Round(e, this));
            }
        }

        Element dependentElement = tournamentElement.getChild("DEPENDENTTOURNAMENTS");
        if (dependentElement != null) {
            for (Element e : dependentElement.getChildren()) {
                dependentTournaments.add(e.getData());
            }
        }

        name = tournamentElement.getStringFromChild("NAME");
        String seeding = tournamentElement.getStringFromChild("SEEDING");
        if (seeding != null && seeding.isEmpty() == false) {
            seedingEnum = InitialSeedingEnum.valueOf(seeding);
        } else {
            seedingEnum = InitialSeedingEnum.RANDOM;
        }

        String pointsString = tournamentElement.getStringFromChild("POINTS");

        if (pointsString != null && pointsString.isEmpty() == false) {
            points = new ArrayList<Integer>();
            for (String s : pointsString.split(",")) {
                points.add(new Integer(s));
            }
        }

        isRandomPairing = tournamentElement.getBooleanFromChild("ISRANDOMPAIRING", true);

        int counter = 1;
        for (Round r : rounds) {
            if (r.isSingleElimination()) {
                getTournamentGUI().getRoundTabbedPane().addSingleEliminationTab(r.getMatches().size() * 2, r.getPanel());
            } else {
                getTournamentGUI().getRoundTabbedPane().addSwissTab(counter, r.getPanel());
                counter++;
            }

        }

        triggerDeepChange();
    }

    public void setupTournamentGUI(RankingTable rankingTable) {
        tournamentGUI = new TournamentGUI(rankingTable);
    }

    public int getRoundNumber(Round round) {
        int count = 0;
        for (Round r : rounds) {
            count++;
            if (r == round) {
                return count;
            }
        }

        return 0;
    }

    public Round getRound(int i) {
        if (rounds == null) {
            return null;
        } else {
            return rounds.get(i);
        }
    }

    public Round getSelectedRound() {
        if (rounds == null) {
            return null;
        } else {
            return getAllRounds().get(getTournamentGUI().getRoundTabbedPane().getSelectedIndex());
        }
    }
    
    public Round getRoundOfMatch(Match m){
    	if (rounds != null) {
            for(Round r : getAllRounds()){
            	if(r.getMatches().contains(m)){
            		return r;
            	}
            }
        }
    	return null;
    }

    public List<Round> getAllRounds() {
        return rounds;
    }

    public int getRoundCount() {
        if (rounds == null) {
            return 0;
        } else {
            return rounds.size();
        }
    }

    public void setPlayers(List<Player> players) {
        this.players = players;
    }

    public List<Player> getPlayers() {
        return players;
    }

    public Set<Player> getAllPlayers() {
        // TreeSets and Head To Head comparisons can have problems.
        // Do not use them together.
        Set<Player> allPlayers = new TreeSet<Player>(getRankingNoHeadToHeadComparator());

        for (Round r : getAllRounds()) {
            for (Match m : r.getMatches()) {
                
                    allPlayers.add(m.getPlayer1());
                    if (m.getPlayer2() != null) {
                        allPlayers.add(m.getPlayer2());
                    }
            }
        }

        allPlayers.addAll(players);

        return allPlayers;
    }

    public TournamentGUI getTournamentGUI() {
        return tournamentGUI;
    }

    public String getName() {
        return name;
    }

    public List<Integer> getPoints() {
        return points;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void updateVisualOptions() {
        if (CryodexController.isLoading == false) {
            for (Round r : getAllRounds()) {
                r.getPanel().resetGamePanels(true);
            }
        }
    }

    public boolean generateNextRound() {

        // All matches must have a result filled in
        String incompleteMatches = getLatestRound().isComplete(this);
        if (incompleteMatches != null) {
            
            if(incompleteMatches.length() > 200){
                incompleteMatches = incompleteMatches.substring(0, 200) + "... and others.";
            }
            
            JOptionPane.showMessageDialog(Main.getInstance(),
                    "<HTML>Current round is not complete. Please complete all matches before continuing<br>" + incompleteMatches);
            return false;
        }

        
            // Regular swiss round checks
            String invalidMatches = getLatestRound().isValid(this);
            if (invalidMatches != null) {
                JOptionPane.showMessageDialog(Main.getInstance(),
                        "<HTML>At least one tournament result is not correct. Check if points are backwards, too high, or a result should be a modified win or tie.<br>"
                                + invalidMatches);
                return false;
            }

            generateRound(getAllRounds().size() + 1);
        return true;
    }

    public void cancelRound(int roundNumber) {
        if (rounds.size() >= roundNumber) {
            // If we are generating a past round. Clear all existing rounds that
            // will be erased.
            while (rounds.size() >= roundNumber) {
                int index = rounds.size() - 1;
                Round roundToRemove = rounds.get(index);
                for (Match m : roundToRemove.getMatches()) {
                    m.clear();
                }
                rounds.remove(roundToRemove);

                getTournamentGUI().getRoundTabbedPane().remove(index);
            }
        }
    }

    public void generateRound(int roundNumber) {

        // if trying to skip a round...stop it
        if (roundNumber > rounds.size() + 1) {
            throw new IllegalArgumentException();
        }

        cancelRound(roundNumber);

        List<Match> matches;

        boolean hasDependentTournaments = dependentTournaments != null && !dependentTournaments.isEmpty();

        if (roundNumber == 1 && !hasDependentTournaments) {
            matches = firstRoundPairings();
        } else {
            matches = getMatches(getPlayers());
        }

        Round r = new Round(matches, this);
        rounds.add(r);
       
        getTournamentGUI().getRoundTabbedPane().addSwissTab(roundNumber, r.getPanel());

        triggerDeepChange();
    }

    protected List<Match> firstRoundPairings() {
        List<Match> matches;
        List<Player> nonPairedPlayers = new ArrayList<>();
        nonPairedPlayers.addAll(getPlayers());

        matches = initialSeedingRandom(nonPairedPlayers);
        
        return matches;
    }

    protected List<Match> initialSeedingRandom(List<Player> players) {
        List<Match> matches = new ArrayList<>();
        Collections.shuffle(players);

        while (!players.isEmpty()) {
        	
        	// If more than 9 pull 4, otherwise pull 3. If less than 3, error.
        	
        	int pullCount = 4;
        	
        	if(players.size() <= 9 && players.size() % 3 == 0){
        		pullCount = 3;
        	}
        	
        	Player player1 = players.get(0);
            Player player2 = players.get(1);
            Player player3 = players.get(2);
            Player player4 = null;
            
            if(pullCount == 4) {
            	player4 = players.get(3);
            }

            players.remove(player1);
            players.remove(player2);
            players.remove(player3);
            if(player4 != null){
            	players.remove(player4);
            }

            Match match = getMatch(player1, player2, player3, player4);
            matches.add(match);
        }
        return matches;
    }

    private List<Match> getMatches(List<Player> userList) {
        List<Match> matches = new ArrayList<Match>();

        List<Player> tempList = new ArrayList<Player>();
        tempList.addAll(userList);
        Collections.sort(tempList, getPairingComparator());

        matches = getRandomMatches(tempList);
        

        return matches;
    }

    public List<Match> getRandomMatches(List<Player> playerList) {
        List<Match> matches = new ArrayList<>();
        Collections.shuffle(playerList);

        while (!playerList.isEmpty()) {
        	
        	// If more than 9 pull 4, otherwise pull 3. If less than 3, error.
        	
        	int pullCount = 4;
        	
        	if(playerList.size() <= 9 && playerList.size() % 3 == 0){
        		pullCount = 3;
        	}
        	
        	Player player1 = playerList.get(0);
            Player player2 = playerList.get(1);
            Player player3 = playerList.get(2);
            Player player4 = null;
            
            if(pullCount == 4) {
            	player4 = playerList.get(3);
            }

            playerList.remove(player1);
            playerList.remove(player2);
            playerList.remove(player3);
            if(player4 != null){
            	playerList.remove(player4);
            }

            Match match = getMatch(player1, player2, player3, player4);
            matches.add(match);
        }
        return matches;
    }

    public StringBuilder appendXML(StringBuilder sb) {

        String playerString = "";
        String seperator = "";
        for (Player p : players) {
            playerString += seperator + p.getSaveId();
            seperator = ",";
        }

        XMLUtils.appendObject(sb, "PLAYERS", playerString);

        XMLUtils.appendList(sb, "ROUNDS", "ROUND", getAllRounds());

        String pointsString = "";
        seperator = "";
        if (points != null) {
            for (Integer p : points) {
                pointsString += seperator + p;
                seperator = ",";
            }
        }

        XMLUtils.appendObject(sb, "ISRANDOMPAIRING", isRandomPairing);
        XMLUtils.appendObject(sb, "POINTS", pointsString);
        XMLUtils.appendObject(sb, "NAME", name);
        XMLUtils.appendObject(sb, "MODULE", getModuleName());
        XMLUtils.appendObject(sb, "SEEDING", seedingEnum);
        XMLUtils.appendStringList(sb, "DEPENDENTTOURNAMENTS", "DEPENDENT", dependentTournaments);

        return sb;
    }

    public void startTournament() {
        generateRound(1);
    }

    public void addPlayer(Player p) {
        if(players.contains(p)){
            return;
        }
        getPlayers().add(p);
        triggerDeepChange();
    }

    public void dropPlayer(Player p) {

        getPlayers().remove(p);
        triggerDeepChange();
    }

    public void massAddPlayers(List<Player> playersToAdd) {

        for (Player p : playersToAdd) {
            addPlayer(p);
        }

        triggerDeepChange();
    }

    public void massDropPlayers(List<Player> playersToDrop) {

        for (Player p : playersToDrop) {
            dropPlayer(p);
        }

        triggerDeepChange();
    }

    public abstract void massDropPlayers(int minScore, int maxCount);

    private void resetRankingTable() {
        getTournamentGUI().getRankingTable().setPlayers(getAllPlayers());
    }

    public int getRoundPoints(int roundNumber) {

        int tournamentPoints = getPointsDefault();

        try {
            if (getPoints() != null && getPoints().isEmpty() == false) {

                tournamentPoints = getPoints().size() >= roundNumber ? getPoints().get(roundNumber - 1) : getPoints().get(getPoints().size() - 1);
            }
        } catch (Exception e) {
            // If a problem occurs then stick to 100. Lets be honest, it's rarely anything else.
            e.printStackTrace();
        }

        return tournamentPoints;
    }

    public void addDependentTournaments(List<Tournament> tournaments) {
        for (Tournament t : tournaments) {
            dependentTournaments.add(t.getName());
        }
    }
    
    public void addDependentTournament(Tournament tournament){
    	dependentTournaments.add(tournament.getName());
    }
    
    public void clearDependentTournaments(){
    	dependentTournaments.clear();
    }

    public abstract int getPointsDefault();

    public List<Tournament> getDependentTournaments() {

        if (dependentTournaments == null || dependentTournaments.isEmpty()) {
            return new ArrayList<Tournament>();
        }

        List<Tournament> dependentList = new ArrayList<Tournament>();

        for (Tournament t : CryodexController.getAllTournaments()) {
            if (t instanceof Tournament && dependentTournaments.contains(t.getName())) {
                dependentList.add(t);
            }
        }

        return dependentList;
    }

    public InitialSeedingEnum getSeedingEnum() {
        return seedingEnum;
    }

    public void triggerChange() {
        CryodexController.saveData();
        getTournamentGUI().getRankingTable().resetPlayers();
    }

    public void triggerDeepChange() {
        CryodexController.saveData();
        resetRankingTable();
    }

    public Module getModule() {
        return module;
    }

    public abstract Icon getIcon();

    public abstract String getModuleName();

    public abstract RoundPanel getRoundPanel(List<Match> matches);

    public abstract TournamentComparator<Player> getRankingComparator();

    public abstract TournamentComparator<Player> getRankingNoHeadToHeadComparator();

    public abstract TournamentComparator<Player> getPairingComparator();

    public abstract ExportController getExportController();

    public Round getLatestRound() {
        if (rounds == null || rounds.isEmpty()) {
            return null;
        } else {
            return rounds.get(rounds.size() - 1);
        }
    }

    public abstract boolean isMatchComplete(Match m);

    public abstract boolean isValidResult(Match m);

    public Match getMatch(Player player1, Player player2, Player player3, Player player4) {
        return new Match(player1, player2, player3, player4);
    }

    public abstract ModulePlayer getModulePlayer(Player p);
}
